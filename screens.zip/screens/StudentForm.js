import React, { useState } from 'react';
import './StudentForm.css';

function StudentForm() {
  const [formData, setFormData] = useState({
    name: '',
    rollNo: '',
    email: '',
    phoneNumber: '',
    age:''
  
  });

  const [students, setStudents] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newStudent = { ...formData };
    setStudents([...students, newStudent]);
    setFormData({
      name: '',
      rollNo: '',
      email: '',
      phoneNumber: '',
      age:''
    });
  };
  const sortStudentsByAge = () => {
    const sortedStudents = [...students].sort((a, b) => a.age - b.age);
    setStudents(sortedStudents);
  };
    const sortStudentsByrollNo = () => {
      const sortedStudents = [...students].sort((a, b) => a.rollNo.localeCompare(b.rollNo));
      setStudents(sortedStudents);
    };

  return (
    <div className='abc'>
      <h2>Student Form</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            placeholder="name"
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Roll Number:</label>
          <input
            type="text"
            name="rollNo"
            value={formData.rollNo}
            placeholder="roll no"
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            placeholder="email"
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Phone Number:</label>
          <input
            type="tel"
            name="phoneNumber"
            value={formData.phoneNumber}
            placeholder="phone"
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Age:</label>
          <input
            type="text"
            name="age"
            value={formData.age}
            placeholder="age"
            onChange={handleChange}
          />
        </div>
      
        <button type="submit">Submit</button>
      </form>
      <h2>Student's Data</h2>
      <button onClick={sortStudentsByAge}>Sort by Age</button>
      <button onClick={sortStudentsByrollNo}>Sort by rollNo</button>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Roll Number</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student, index) => (
            <tr key={index}>
              <td>{student.name}</td>
              <td>{student.rollNo}</td>
              <td>{student.email}</td>
              <td>{student.phoneNumber}</td>
              <td>{student.age}</td>
             
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentForm ;
